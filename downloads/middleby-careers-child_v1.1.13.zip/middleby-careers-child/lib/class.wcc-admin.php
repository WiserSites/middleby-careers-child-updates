<?php

class WCC_Admin {

	private static $initiated = false;

	private static $career_api_url = 'https://careers.middleby.com/wp-json/wiser/v1/career';

	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	/**
	 * Initializes WordPress hooks
	 */
	private static function init_hooks() {
		self::$initiated = true;
		require_once( WCC_PLUGIN_DIR . 'view/admin/wcc_settings.php' );

		add_action( 'admin_menu', array( 'WCC_Admin', 'init_menus' ), 10, 2 );

		// Ajax.
		add_action( 'wp_ajax_mbek_get_jobs', array( 'WCC_Admin', 'get_jobs' ) );
		add_action( 'wp_ajax_nopriv_mbek_get_jobs', array( 'WCC_Admin', 'get_jobs' ) );

		add_action( 'wp_ajax_mbek_get_terms', array( 'WCC_Admin', 'get_terms' ) );
		add_action( 'wp_ajax_nopriv_mbek_get_terms', array( 'WCC_Admin', 'get_terms' ) );

		add_action( 'wp_ajax_mbek_get_departments', array( 'WCC_Admin', 'get_departments' ) );
		add_action( 'wp_ajax_nopriv_mbek_get_departments', array( 'WCC_Admin', 'get_departments' ) );

		add_action( 'wp_ajax_get_locations', array( 'WCC_Admin', 'get_locations' ) );
		add_action( 'wp_ajax_nopriv_get_locations', array( 'WCC_Admin', 'get_locations' ) );

		add_action( 'wp_ajax_mbek_get_brands', array( 'WCC_Admin', 'get_brands' ) );
		add_action( 'wp_ajax_nopriv_mbek_get_brands', array( 'WCC_Admin', 'get_brands' ) );

		add_action( 'wp_ajax_mbek_get_options', array( 'WCC_Admin', 'get_options' ) );
		add_action( 'wp_ajax_nopriv_mbek_get_options', array( 'WCC_Admin', 'get_options' ) );
	}

	public static function get_options() {
		$options = get_option( 'wcc_options' );

		if ( ! empty( $options ) ) {
			$returnOptions = array(
				'fetch_all'        => (bool) ( $options['wcc_fetch_all'] ?? false ),
				'show_brands'      => (bool) ( $options['wcc_show_brands'] ?? false ),
				'show_departments' => (bool) ( $options['wcc_show_departments'] ?? false ),
				'show_locations'   => (bool) ( $options['wcc_show_locations'] ?? false ),
                'brand_filter'     => $options['wcc_brand_filter'] ?? '',
			);
			wp_send_json_success( $returnOptions, 200 );
		} else {
			wp_send_json_error( new WP_Error( '001', 'No data!', 'No Options Exists!' ), 200 );
		}

	}

	public static function get_jobs() {
//		$page      = filter_var( $_REQUEST['page'], FILTER_VALIDATE_INT ) ?? 1;
		$url       = self::$career_api_url;
		$options   = get_option( 'wcc_options' );
		$fetch_all = $options['wcc_fetch_all'] ?? false;
		if ( empty( $fetch_all ) ) {
			$url .= '/user/1';
		}
		$request = WCC_Admin::fetch( $url );
		// Retrieve information
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );

		switch ( $response_code ) {
			case 400:
				// If error...
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );
				break;
			case 200:
				// If success...
				$data     = json_decode( $response_body );
				$new_data = array(
//					'total'       => $total,
//					'total_pages' => $total_pages,
					'jobs'        => $data,
				);
				wp_send_json_success( $new_data, 200 );
				break;
		}
	}

	public static function fetch( $url ) {
		if ( strpos( $url, '?' ) ) {
			$url .= '&t=' . time();
		} else {
			$url .= '?t=' . time();
		}
		$options = get_option( 'wcc_options' );
		$user    = $options['wcc_app_username'];
		$pass    = $options['wcc_app_password'];
		$args    = array(
			'sslverify' => false,
			'headers'   => array(
				'Authorization' => 'Basic ' . base64_encode( "$user:$pass" ),
				'pragma'        => 'no-cache',
				'cache-control' => 'no-cache',
			)
		);
		$request = wp_remote_request( $url, $args );

		return $request;
	}

	public static function init_menus() {
		add_menu_page( 'Middleby Careers', 'Middleby Careers', 'manage_options', 'wcc', 'wcc_options_page_html', 'dashicons-align-center', '80.08' );
		add_submenu_page( 'wcc', 'Shortcodes', 'Shortcodes', 'manage_options', 'wcc-shortcodes', array(
			'WCC_Admin',
			'i_shortcodes'
		) );
//		add_options_page(
//			'Careers Settings',
//			'Careers Settings',
//			'manage_options',
//			'wiser-careers-child_settings',
//			array( 'WCC_Admin', 'i_settings' ),
//			1
//		);

	}

	public static function wcc_css_and_js() {
		wp_enqueue_script( 'wcc-admin-js', WCC_PLUGIN_URL . 'resources/js/admin_js.js', array(), WCC_VERSION, true );
		wp_localize_script( 'wcc-admin-js', 'wcc_infos',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				/*'loadingmessage' => __('Sending info, please wait...'),
				'loading_img' => '<img src="'.WPC_PLUGIN_URL.'images/loading.gif" id="i_loading_img">',
				'site_url' => site_url(),*/
			)
		);
	}

	public static function i_shortcodes() {
		self::wcc_css_and_js();
		include WCC_PLUGIN_DIR . 'view/admin/wcc_shortcodes.php';
	}

	public static function i_settings() {
		self::wcc_css_and_js();
		include WCC_PLUGIN_DIR . 'view/admin/wcc_settings.php';
	}


	/*
	 * AJAX
	 */
	public static function get_terms() {
		$url = self::$career_api_url . '/terms';
		if ( isset( $_REQUEST['parent'] ) && $parent_id = filter_var( $_REQUEST['parent'], FILTER_VALIDATE_INT ) ) {
			$url .= '/' . $parent_id;
		}
//		trigger_error( '$url: ' . $url, E_USER_NOTICE );
		$request = WCC_Admin::fetch( $url );
		// Retrieve information
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );
		switch ( $response_code ) {
			case 400:
				// If error...
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );
				break;
			case 200:
				// If success...
				$data = json_decode( $response_body );
				wp_send_json_success( $data, 200 );
				break;
		}
	}

	public static function get_brands() {
		$url       = self::$career_api_url . '/brands';
		$options   = get_option( 'wcc_options' );
		$fetch_all = $options['wcc_fetch_all'] ?? false;
		if ( empty( $fetch_all ) ) {
            $url .= '/user/1';
//			wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );

//			return;
		}
//		trigger_error( '$url: ' . $url, E_USER_NOTICE );
		$request = WCC_Admin::fetch( $url );
		// Retrieve information
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );
		switch ( $response_code ) {
			case 400:
				// If error...
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );
				break;
			case 200:
				// If success...
				$data = json_decode( $response_body );
				wp_send_json_success( $data, 200 );
				break;
		}
	}

	public static function get_departments() {
		$url       = self::$career_api_url . '/department';
		$options   = get_option( 'wcc_options' );
		$fetch_all = $options['wcc_fetch_all'];
		if ( empty( $fetch_all ) ) {
//			$url .= '/user/1';
		}
//		trigger_error( '$url: ' . $url, E_USER_NOTICE );
		$request = WCC_Admin::fetch( $url );
		// Retrieve information
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );
		switch ( $response_code ) {
			case 400:
				// If error...
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );
				break;
			case 200:
				// If success...
				$data = json_decode( $response_body );
				wp_send_json_success( $data, 200 );
				break;
		}
	}

	public static function get_locations() {
		$url       = self::$career_api_url . '/location';
		$options   = get_option( 'wcc_options' );
		$fetch_all = $options['wcc_fetch_all'];
		if ( empty( $fetch_all ) ) {
//			$url .= '/user/1';
		}
//		trigger_error( '$url: ' . $url, E_USER_NOTICE );
		$request = WCC_Admin::fetch( $url );
		// Retrieve information
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );
//		trigger_error( 'response code: ' . $response_code, E_USER_NOTICE );
		switch ( $response_code ) {
			case 400:
				// If error...
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 200 );
				break;
			case 200:
				// If success...
				$data = json_decode( $response_body );
//				trigger_error( 'response code data: ' . print_r( $data, true ), E_USER_NOTICE );
				wp_send_json_success( $data, 200 );
				break;
		}
	}

}
