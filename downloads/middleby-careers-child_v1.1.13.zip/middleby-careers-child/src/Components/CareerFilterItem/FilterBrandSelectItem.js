import React, {useState} from 'react';
import FilterBrandSelectOption from "./FilterBrandSelectOption";

const FilterBrandSelectItem = (props) => {
    const changeSelected = (newSelect) => {
        // console.log('newSelect: ', newSelect);
        props.onBrandChangeActive(newSelect, true);
        // props.onBrandChangeActive(props.options.find(option => option.id === parseInt(newSelect)), true);
    };

    if (!props.show) {
        return null;
    }

    let currentSelection = '';
    if (props.currentSelect) {
        // console.log('props.currentSelect: ', props.currentSelect);
        currentSelection = props.currentSelect[0];
    }

    return (
        <div className="col-sml-12 col-md-3">
            <div className="mb-3">
                <label>{props.title}</label>
                <select
                    onChange={(event) => changeSelected(event.target.value)}
                    value={currentSelection}
                    className="form-select"
                    aria-label="Default select">
                    <option value="">- Select {props.title} -</option>
                    {props.options.map((option) => <FilterBrandSelectOption key={option.id} option={option} />)}
                </select>
            </div>
        </div>
    );
};

export default FilterBrandSelectItem;
