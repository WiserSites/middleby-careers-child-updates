import React from 'react';

const FilterBrandSelectOption = (props) => {

    return (
        <option key={props.option.id} value={props.option.id}>
            {props.option.display_name}
        </option>
    );
};

export default FilterBrandSelectOption;
