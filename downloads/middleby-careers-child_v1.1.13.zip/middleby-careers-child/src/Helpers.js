import React from 'react';
import 'regenerator-runtime';

export const getJSON = async function (url, errorMsg = 'Something went wrong') {
    return fetch(url).then(response => {
        if (!response.ok) throw new Error(`${errorMsg} ${response.status}`);

        return response.json();
    });
};

export const renderError = function(msg){
    console.log(msg);
};

export const careerScrollToTop = () => {
    // Scroll to top of the App.
    const appTop = document.querySelector('#career-app-list');
    const getOffset = (element, horizontal = false) => {
        if(!element) return 0;
        return getOffset(element.offsetParent, horizontal) + (horizontal ? element.offsetLeft : element.offsetTop);
    }
    window.scrollTo({
        top: getOffset(appTop) - 150,
        left: getOffset(appTop, true),
        behavior: 'smooth'
    });
};