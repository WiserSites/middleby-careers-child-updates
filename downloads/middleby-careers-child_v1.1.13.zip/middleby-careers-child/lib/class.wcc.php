<?php

class WCC {

	private static $initiated = false;

	public static function init() {

		if ( ! self::$initiated ) {
			self::init_hooks();
		}

	}

	/**
	 * Initializes WordPress hooks
	 */
	private static function init_hooks() {
		self::$initiated = true;

		add_action( 'wp_enqueue_scripts', array( 'WCC', 'load_resources' ) );
	}

	public static function plugin_activation() {

	}

	public static function load_resources() {
		//WPC_PLUGIN_URL.'resources/style/admin_style.css
//		wp_enqueue_style( 'wpc_style', WCC_PLUGIN_URL . 'resources/style/front_style.css', array(), WCC_VERSION, 'all' );
	}

	/**
	 * Removes all connection options
	 * @static
	 */
	public static function plugin_deactivation() {
		//flush_rewrite_rules();
	}

}