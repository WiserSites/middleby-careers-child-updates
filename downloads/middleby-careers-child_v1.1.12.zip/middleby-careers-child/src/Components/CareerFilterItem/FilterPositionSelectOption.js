import React from 'react';

const FilterPositionSelectOption = (props) => {
  const disabledStatus = ! props.filtered.find((job) => job.id === props.option.id);
    return (
        <option key={props.option.id} value={props.option.id} disabled={disabledStatus} >
            {props.option.title}
        </option>
    );
};

export default FilterPositionSelectOption;
