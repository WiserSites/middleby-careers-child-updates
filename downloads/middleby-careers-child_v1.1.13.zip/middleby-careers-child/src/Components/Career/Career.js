import React from 'react';
import Location from "../Location/Location";
import './Career.css';

const Career = (props) => {

    const showJobHandler = (event) => {
        props.onShowDetail(props.job);
    };

    return (
        <div className="col-xs-12 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-xxl-3 px-3 h-100 d-inline-block">
            <div className="career_container" onClick={showJobHandler}>
                <div className="career_title">
                    <h4>{props.job.title}</h4>
                    {props.job.company_name}
                </div>
                <Location location={props.job.location} />
            </div>
        </div>
    );
}

export default Career;