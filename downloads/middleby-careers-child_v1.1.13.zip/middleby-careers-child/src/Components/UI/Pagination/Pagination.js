import React from 'react';
import PaginationItem from "./PaginationItem";
import {careerScrollToTop} from "../../../Helpers";
import './Pagination.css';

const Pagination = props => {
    const onItemClickHandler = (page_number) => {
        props.onPageChange(page_number);
        careerScrollToTop();
    };
    const onPrevClickHandler = (event) => {
        event.preventDefault();
        props.onPrevHandler();
        careerScrollToTop();
    };
    const onNextClickHandler = (event) => {
        event.preventDefault();
        props.onNextHandler();
        careerScrollToTop();
    };

    if (props.showPagination === false) {
      return null;
    }

    return (
        <div className='wiser_career_pagination'>
            {(props.currentPage > 1) ? <a onClick={onPrevClickHandler} href='' className='page-numbers'>Prev</a> : null}
            {props.pages.map((item) => <PaginationItem key={item} currentPage={props.currentPage} pageItem={item} onItemClickHandler={onItemClickHandler} />)}
            {(props.currentPage < props.totalPages) ? <a onClick={onNextClickHandler} href='' className='page-numbers'>Next</a> : null}
        </div>
    );
};

export default Pagination;
