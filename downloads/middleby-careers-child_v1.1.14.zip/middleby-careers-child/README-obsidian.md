# Middleby Careers Child Plugin

> [!info] Project Overview
> Middleby Careers Child Plugin is a WordPress plugin designed to display career opportunities. It integrates with the Paylocity API and provides a customizable frontend experience.

## 🛠️ Setup & Configuration

### Installation
1. Upload the plugin files to the `/wp-content/plugins/middleby-careers-child` directory.
2. Activate the plugin through the **Plugins** screen in WordPress.

### Admin Configuration
Navigate to **Careers Settings** in the WordPress admin dashboard.

#### API Settings
| Field | Description |
| --- | --- |
| **Fetch All Middleby** | Fetch all jobs from the Middleby API. |
| **Show Filters** | Toggle visibility of Brands, Departments, and Locations filters. |
| **Credentials** | Enter Application Username, Password, and Paylocity KEY. |
| **Brand Filter** | Set a default brand filter for the job list. |
| **Share Info** | Customize title, content, and button for job sharing. |

## 🚀 Usage

Use the following shortcode to embed the careers application:

`[middleby-careers-app]`

### Shortcode Attributes
- `site_id`: Filter by specific site ID.
- `brand`: Filter by specific brand name.

## 💻 Developer Setup

### Prerequisites
- [[Node.js]] 20.17.0
- [[nvm]] recommended

### Commands
1. **Initialize Environment**
   ```bash
   nvm use 20.17.0
   export NODE_OPTIONS=--openssl-legacy-provider
   npm install
   ```

2. **Development**
   ```bash
   npm run watch
   ```

3. **Production Build**
   ```bash
   npm run build
   ```

---
**Author:** Simple Schema
**Website:** [wisersites.com](https://wisersites.com)
**Version:** 1.1.13
