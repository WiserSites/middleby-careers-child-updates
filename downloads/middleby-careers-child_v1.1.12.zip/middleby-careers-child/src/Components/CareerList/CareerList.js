import React, {useState, useEffect, Fragment} from 'react';
import {getJSON, renderError, careerScrollToTop} from "../../Helpers";
import Career from "../Career/Career";
import CareerFilters from "../CareerFilters/CareerFilters";
import Pagination from "../UI/Pagination/Pagination";
import 'regenerator-runtime';
import './CareerList.css';
// import {prettifyTargets} from "@babel/preset-env/lib/utils";
import ClearFilter from "../UI/Button/ClearFilter";
import {render} from "react-dom";
import Share from "../Share/Share";

const CareerList = (props) => {
    const brand_filter_setting = (typeof wcc_brand_filter === 'undefined') ? false : wcc_brand_filter;
    const resultsPerPage = 12;

    const [fetchAllMiddleby, setFetchAllMiddleby] = useState(true);

    const [brandSelected, setBrandSelected] = useState(false);
    const [deptSelected, setDeptSelected] = useState(false);
    const [locSelected, setLocSelected] = useState(false);
    const [positionSelected, setPositionSelected] = useState(false);

    const [jobs, setJobs] = useState([]);
    const [brands, setBrands] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [locations, setLocations] = useState([]);
    const [selectedTerms, setSelectedTerms] = useState([]);

    const [selectedBrands, setSelectedBrands] = useState([]);
    const [selectedDepartments, setSelectedDepartments] = useState([]);
    const [selectedLocations, setSelectedLocations] = useState([]);

    const [page, setPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [q, setQ] = useState('');

    const [firstLoad, setFirstLoad] = useState(true);

    useEffect(() => {
        const fetchJobs = async () => {
            const jobs = await getJSON(wcc_ajax_url + '?action=mbek_get_jobs')
                .then((jobs) => {
                    if (!jobs.success) {
                        if (!jobs) {
                            renderError('ERROR: Something went wrong!');
                        } else if (jobs) {
                            renderError(jobs.data[0].message);
                        }
                        // throw new Error(`Error: Something went wrong!`)
                        setLoading(false);
                    } else {
                        let aDepartment = [];

                        setJobs(jobs.data.jobs);
                        setLoading(false);
                    }
                })
                .catch((err) => renderError(err))
                .finally(() => setLoading(false));
        };
        fetchJobs();
    }, []);
    useEffect(() => {
        const fetchBrands = async () => {
            const brands = await getJSON(wcc_ajax_url + '?action=mbek_get_brands')
                .then((brands) => {
                    if (!brands.success) {
                        if (! brands) {
                            renderError('Error something is wrong!');
                        } else if (brands) {
                            renderError(brands.data[0].message);
                        }

                    } else {
                        setBrands(brands.data);
                        // Set brands if option for brand filter is set.
                        if (brand_filter_setting) {
                            // Find correct brand.
                            // console.log('brands: ', brands);
                            if (brands.data.length > 0){
                                const brand_restriction = brands.data.find((brand) => brand.id == brand_filter_setting);
                                setBrands([brand_restriction]);
                            }
                        }
                    }
                })
                .catch((err) => renderError(err));
        };
        const fetchDepartments = async () => {
            const deps = await getJSON(wcc_ajax_url + '?action=mbek_get_departments')
                .then((deps) => {
                    if (!deps.success) {
                        renderError(deps.data[0].message);
                    } else {
                        setDepartments(deps.data);
                    }
                })
                .catch((err) => renderError(err));
        };
        const fetchLocations = async () => {
            const locs = await getJSON(wcc_ajax_url + '?action=mbek_get_locations')
                .then((locs) => {
                    if (!locs.success) {
                        renderError(locs.data[0].message);
                    } else {
                        setLocations(locs.data);
                    }
                })
                .catch((err) => renderError(err));
        };
        // fetchMainTerms();
        fetchBrands();
        // fetchDepartments();
        // fetchLocations();
    }, []);

    const onChangeFetchAllOption = (fetchAllOption) => {
        setFetchAllMiddleby(fetchAllOption);
    };
    const onChangeFilterHandler = (term_id, isChecked) => {
        setFirstLoad(false);
        onPageResetHandler();

        if ( term_id ) {
            setSelectedTerms(term_id);
        } else {
            setSelectedTerms([]);
        }
    };
    const resetBrandFilters = () => {
      setBrandSelected(false);
      filteredBrands = [];
      setBrands((prevBrands) => {
        return brands.map((brand) => {
          brand.selected = false;
          return brand;
        });
      });
      setSelectedBrands((prevFilteredBrands) => []);
    };
    const resetDepartmentFilters = () => {
      setSelectedDepartments(false);
      filteredDepartments = [];
      // reset departments.
      activeDepartments = activeDepartments.map((dept) => {
        dept.selected = false;
        return dept;
      });
      setDepartments((prevDeps) => {
        return departments.map((term) => {
          term.selected = false;
          return term;
        });
      });

    };
    const resetLocationFilters = () => {
      setSelectedLocations(false);
      filteredLocations = [];
      // reset locations.
      activeLocations = activeLocations.map((dept) => {
        dept.selected = false;
        return dept;
      });
      setLocations((prevLocs) => {
        return locations.map((term) => {
          term.selected = false;
          return term;
        });
      });

    };
    const resetPositionFilters = () => {
      setPositionSelected(false);

    };
    const resetAllFilters = () => {
        setQ('');
        resetBrandFilters();
        resetDepartmentFilters();
        resetLocationFilters();
        // setDeptSelected(false);
        // setLocSelected(false);
        // reset brands.
        setSelectedTerms(prevFilteredTerms => []);
    };
    const onChangeDepartmentHandler = (term_id, isChecked, taxonomy) => {
        setFirstLoad(false);
        onPageResetHandler();

        switch (taxonomy){
            case 'department':
                resetLocationFilters();
                resetPositionFilters();
                setSelectedDepartments([term_id]);
                break;
            case 'location':
                resetPositionFilters();
                setSelectedLocations([term_id]);
                break;
        }

        setSelectedTerms((prevTerms) => {
            // Remove the old term_id from this taxonomy.
            const newTerms = prevTerms.filter((term) => {
                if (taxonomy === 'department') {
                    if (activeDepartments.find((dept) => dept.term_id === term)) {
                        return false;
                    } else {
                        return true;
                    }
                } else if (taxonomy === 'location') {
                    if (activeLocations.find((loc) => loc.term_id === term)) {
                        return false;
                    } else {
                        return true;
                    }
                }
            });
            if (isChecked) {
                if (term_id === '') {
                    // Here the department drop down empty option is selected. Need to remove all departments.
                    return newTerms;
                } else {
                    return [parseInt(term_id), ...newTerms];
                }
                // return [parseInt(term_id), ...prevTerms];
            } else {
                if (prevTerms.length === 0) {
                    return [];
                } else {
                    return newTerms;
                }
            }
        });
    };
    const onChangeBrandHandler = (brand, isChecked) => {
      // console.log('brand', brand);
        setFirstLoad(false);
        onPageResetHandler();
        resetAllFilters();
        // setBrandSelected(true);
        // setDeptSelected(false);
        // setLocSelected(false);
        setPositionSelected(false);
       // setPositionSelected([]);
        if ( ! brand ) {
            setSelectedBrands([]);
            setBrandSelected([]);
        } else {
          // props.onBrandChangeActive(props.options.find(option => option.id === parseInt(newSelect)), true);

            setSelectedBrands([brand]);
            setBrandSelected([brand]);
        }
        // setQ('');
        // setSelectedDepartments(false);
        // setSelectedLocations(false);
        // filteredDepartments = [];
        // filteredLocations = [];
        // setSelectedTerms(prevFilteredTerms => []);
    };
    const onChangeSearch = (newSearch) => {
        setFirstLoad(false);
        onPageResetHandler();
        setQ(newSearch);
    };
    const onChangePositionHandler = (job, isChecked) => {
        setFirstLoad(false);
        onPageResetHandler();
        // resetAllFilters();
        // setBrandSelected(false);
        // setDeptSelected(false);
        // setLocSelected(false);
        // setSelectedDepartments(false);
        // setSelectedLocations(false);
        // filteredDepartments = [];
        // filteredLocations = [];
        // filteredBrands = [];
        // setSelectedTerms(prevFilteredTerms => []);
        if ( ! job ) {
            setPositionSelected([]);
        } else {
            setPositionSelected([job]);
        }
    };

    const resetFiltersHandler = (event) => {
        setFirstLoad(false);
        onPageResetHandler();
        resetAllFilters();
        // setQ('');
        // setBrandSelected(false);
        // setSelectedDepartments(false);
        // setSelectedLocations(false);
        // setPositionSelected(false);
        //
        // // setDeptSelected(false);
        // // setLocSelected(false);
        // // reset brands.
        // filteredBrands = [];
        // filteredDepartments = [];
        // filteredLocations = [];
        // setBrands((prevBrands) => {
        //     return brands.map((brand) => {
        //         brand.selected = false;
        //         return brand;
        //     });
        // });
        // // reset departments.
        // activeDepartments = activeDepartments.map((dept) => {
        //     dept.selected = false;
        //     return dept;
        // });
        // setDepartments((prevDeps) => {
        //     return departments.map((term) => {
        //         term.selected = false;
        //         return term;
        //     });
        // });
        // // reset locations.
        // activeLocations = activeLocations.map((dept) => {
        //     dept.selected = false;
        //     return dept;
        // });
        // setLocations((prevLocs) => {
        //     return locations.map((term) => {
        //         term.selected = false;
        //         return term;
        //     });
        // });
        // setSelectedTerms(prevFilteredTerms => []);
        // setSelectedBrands((prevFilteredBrands) => []);
    };

    if (!jobs) return <div>Loading...</div>;

    const filteredJobs = jobs.filter((job) => {
        // console.log('positionSelected', positionSelected);
        // console.log('selectedTerms: ', selectedTerms);
        let showJob = false;
        let showTerm = false;
        let showBrand = false;

      // console.log('brand_firlter_setting: ', brand_filter_setting);

        if (brand_filter_setting && brands) {
            if (job.brand.term_id != brand_filter_setting) {
                return false;
            }
        }

        if (selectedTerms.length === 0 && selectedBrands.length === 0) {
            showJob = true;
        }
        if (selectedTerms.length > 0) {
            showTerm = selectedTerms.every((term_id) => {
                for (let i = 0; i < job.terms.length; i++) {
                    if (job.terms[i].term_id === term_id) {
                        return true;
                    }
                }
                return false;
            });
        } else {
            showTerm = true;
        }

        // console.log('showBrand: ', showBrand);
        // console.log('selectedBrands: ', selectedBrands);
        if (selectedBrands.length > 0) {
            showBrand = selectedBrands.every((brand) => {
                // console.log('job 200',job);
                if (job.brand && job.brand.term_id === parseInt(brand)) {
                    return true;
                }
                return false;
            });
        } else {
            showBrand = true;
        }
        if (showBrand && showTerm) {
            showJob = true;
        }
        if ( showJob && positionSelected.length >= 1) {
            // return parseInt(positionSelected[0]) === job.id;
        }
        // If q (search) has any input then search the following:
        // Title
        // Description
        // Requirements
        // Salary Description
        // Departments
        // Locations
        // Brand (if Fetch all Middleby is checked)
        // if (showJob === true && q.length >= 1) {
        //     const searchTerm = q.toLowerCase();
        //     if (job.title.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else if (job.description.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else if (job.requirements.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else if (job.salary_description.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else if (job.location.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else if (fetchAllMiddleby === true && job.brand.name.toLowerCase().indexOf(searchTerm) !== -1) {
        //         showJob = true;
        //     } else {
        //         // console.log('showJob: false');
        //         showJob = false;
        //     }
        // }

        return showJob;
    });
    let activeTerms = [];
    let activeDepartments = [];
    let activeLocations = [];
    let activeBrands = [];
    jobs.forEach((job) => {
        // Loop over this job's terms
        if (job.terms.length > 0) {
            if (brand_filter_setting && brands) {
                if (job.brand.term_id != brand_filter_setting) {
                    return false;
                }
            }
            job.terms.forEach((term) => {
                if (!activeDepartments.find((dept) => term.term_id === dept.term_id)) {
                    if (term.taxonomy === 'career-departments'){
                        activeDepartments.push(term);
                    }
                }
                if (!activeLocations.find((loc) => term.term_id === loc.term_id)) {
                    if (term.taxonomy === 'career-locations') {
                        activeLocations.push(term);
                    }
                }
            });
        }
        // check for brand
        if (!activeBrands.find((brand) => job.brand && brand.term_id === job.brand.term_id)) {
            if (job.brand) {
                activeBrands.push(job.brand);
                // On active brand.
            }
        }
    });
    activeDepartments = activeDepartments.sort((dept1, dept2) => {
        if (dept1.name < dept2.name) {
            return -1;
        }
        if (dept1.name > dept2.name) {
            return 1;
        }
        return 0;
    } );
    activeLocations = activeLocations.sort((loc1, loc2) => {
        if (loc1.name < loc2.name) {
            return -1;
        }
        if (loc1.name > loc2.name) {
            return 1;
        }
        return 0;
    } );
    let filteredDepartments = [];
    let filteredLocations = [];
    let filteredBrands = [];

    filteredJobs.forEach((job) => {
        if (brand_filter_setting && brands) {
            if (job.brand.term_id != brand_filter_setting) {
                return false;
            }
        }
        // check for brand
        if (!filteredBrands.find((brand) => job.brand && brand.term_id === job.brand.term_id)) {
            if (job.brand) {
                filteredBrands.push(job.brand);
            }
        }
        // Loop over this job's terms
        if (job.terms.length > 0) {
            job.terms.forEach((term) => {
                if (!filteredDepartments.find((dept) => term.term_id === dept.term_id)) {
                    if (term.taxonomy === 'career-departments'){
                        filteredDepartments.push(term);
                    }
                }
                if (!filteredLocations.find((loc) => term.term_id === loc.term_id)) {
                    if (term.taxonomy === 'career-locations') {
                        filteredLocations.push(term);
                    }
                }
            });
        }
    });

    let currentJobs = [];
    let pages = [];
    let totalPages = 0;
    let showPagination = true;

    if ( firstLoad === true && fetchAllMiddleby === true ) {
        // console.log('first load');
    } else {
        totalPages = Math.ceil(filteredJobs.length / resultsPerPage);
    }

    // console.log('jobs: ', filteredJobs);
    if (filteredJobs.length >= resultsPerPage && firstLoad === false) {
        currentJobs = filteredJobs.slice((page - 1) * resultsPerPage, page * resultsPerPage);
        for (let i = 1; i <= totalPages; i++) {
            pages.push(i);
        }
    } else {
        currentJobs = filteredJobs;
    }
    if ( positionSelected.length >= 1) {
        const selectedJob = filteredJobs.find((job) => parseInt(positionSelected[0]) === job.id);
        currentJobs = [selectedJob];
        showPagination = false;
    }
    if ( firstLoad === true && fetchAllMiddleby === true ) {
        currentJobs = [];
    }

    const onShowDetailHandler = (job) => {
        props.onShow(job);
    };

    if (loading) {
        return (
            <div className='spinner-container'>
                <div className='loading-spinner'></div>
            </div>
        );
    }

    const onPageChangeHandler = (page_number) => {
        setPage((prev_page_number) => page_number);
    };

    const onPrevHandler = () => {
        setPage(page - 1);
    };

    const onNextHandler = () => {
        setPage(page + 1);
    };

    const onPageResetHandler = () => {
        setPage((prev_page_number) => 1);
    };

    const paylocity = wcc_paylocity;

    if ( jobs.length === 0 ) {
        // return null;
    }

  // console.log('filteredJobs: ', filteredJobs);

    return (
        <Fragment>
            <div className="row">
                <div className="col-sm-12">
                    <ClearFilter onClearAll={resetFiltersHandler}/>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-12 col-md-12">
                    <CareerFilters
                        search={q}
                        fetchAllOption={onChangeFetchAllOption}
                        jobs={jobs}
                        brands={brands}
                        positionSelected={positionSelected}
                        brandSelected={brandSelected}
                        departmentSelected={selectedDepartments}
                        locationSelected={selectedLocations}
                        departments={activeDepartments}
                        locations={activeLocations}
                        activeDepartments={activeDepartments}
                        activeBrands={activeBrands}
                        filteredJobs={filteredJobs}
                        filteredBrands={filteredBrands}
                        filteredDepartments={filteredDepartments}
                        filteredLocations={filteredLocations}
                        onChangeFilter={onChangeFilterHandler}
                        onChangeDepartment={onChangeDepartmentHandler}
                        onChangeBrand={onChangeBrandHandler}
                        onChangePosition={onChangePositionHandler}
                        resetFilters={resetFiltersHandler}
                        onChangeSearch={onChangeSearch}
                    />
                </div>
                <div id='career-app-list' className="col-sm-12 col-md-12 career-job-container">
                    <div className="row gx-2 gx-lg-3">
                        {currentJobs.map((job) => <Career job={job} key={job.id.toString()}
                                                          onShowDetail={onShowDetailHandler}/>)}
                    </div>
                    <div className='row gx-2 gx-lg-3'>
                        <Pagination
                            currentPage={page}
                            pages={pages}
                            totalPages={totalPages}
                            onPageChange={onPageChangeHandler}
                            onPrevHandler={onPrevHandler}
                            onNextHandler={onNextHandler}
                            showPagination={showPagination}
                        />
                    </div>
                    <Share paylocity={paylocity}></Share>
                </div>
            </div>
        </Fragment>
    );
};

export default CareerList;
