<?php
function wcc_settings_init(){
	register_setting('wcc', 'wcc_options');
	// Register a new section in the "wcc" page.
	add_settings_section(
		'wcc_section_api',
		__( 'Middleby Career API Settings', 'wcc' ),
		'wcc_section_api_callback',
		'wcc'
	);

	add_settings_field(
		'wcc_fetch_all',
		__( 'Fetch All Middleby', 'wcc' ),
		'wcc_field_checkbox',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_fetch_all',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_show_brands',
		__( 'Show Brands', 'wcc' ),
		'wcc_field_checkbox',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_show_brands',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_show_departments',
		__( 'Show Departments', 'wcc' ),
		'wcc_field_checkbox',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_show_departments',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_show_locations',
		__( 'Show Locations', 'wcc' ),
		'wcc_field_checkbox',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_show_locations',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_client_id',
		__( 'Application Username', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_app_username',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_client_secret',
		__( 'Application Password', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_app_password',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_paylocity_key',
		__( 'Paylocity KEY', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_paylocity_key',
			'class'     => 'wcc_row',
		)
	);

    add_settings_field(
        'wcc_brand_filter',
        __( 'Brand Filter', 'wcc' ),
        'wcc_field_brand_filter',
        'wcc',
        'wcc_section_api',
        array(
            'label_for' => 'wcc_brand_filter',
            'class'     => 'wcc_row',
        )
    );

	add_settings_field(
		'wcc_share_title',
		__( 'Share Info Title', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_share_title',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_share_content',
		__( 'Share Info Content', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_share_content',
			'class'     => 'wcc_row',
		)
	);

	add_settings_field(
		'wcc_share_button',
		__( 'Share Button Text', 'wcc' ),
		'wcc_field_text',
		'wcc',
		'wcc_section_api',
		array(
			'label_for' => 'wcc_share_button',
			'class'     => 'wcc_row',
		)
	);
}
/**
 * Register our wcc_settings_init to the admin_init action hook.
 */
add_action( 'admin_init', 'wcc_settings_init' );
/**
 * API section callback function.
 *
 * @param array $args  The settings array, defining title, id, callback.
 */
function wcc_section_api_callback( $args ) {
	?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Middleby Careers API Credentials', 'wcc' ); ?></p>
	<?php
}
/**
 * DB section callback function.
 *
 * @param array $args  The settings array, defining title, id, callback.
 */
function wcc_section_db_callback( $args ) {
	?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Middleby Careers Database Settings', 'wcc' ); ?></p>
	<?php
}
/**
 * Text field callback function.
 *
 * WordPress has magic interaction with the following keys: label_for, class.
 * - the "label_for" key value is used for the "for" attribute of the <label>.
 * - the "class" key value is used for the "class" attribute of the <tr> containing the field.
 * Note: you can add custom key value pairs to be used inside your callbacks.
 *
 * @param array $args
 */
function wcc_field_text( $args ) {
	$options = get_option( 'wcc_options' );
	?>
    <input
            class="form-control"
            type="text"
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="wcc_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            value="<?php echo esc_attr( $options[ $args['label_for'] ] ); ?>" />
	<?php
}
function wcc_field_checkbox( $args ) {
    $options = get_option( 'wcc_options' );
	?>
    <input
            class="form-control"
            type="checkbox"
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="wcc_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            value="true" <?php if ( isset( $options[ $args['label_for'] ] ) ) {
		echo ( $options[ $args['label_for'] ] === 'true' ) ? 'checked' : '';
	} ?> />
	<?php
}
function wcc_field_brand_filter( $args ) {
    $options  = get_option( 'wcc_options' );
    $ajax_url = admin_url( 'admin-ajax.php' );
    ?>
    <select id="brand_filter" name="wcc_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
        <option value=""></option>
    </select>
    <script>
        const brand_filter = <?php echo ( $options[ $args['label_for'] ] ) ? $options[ $args['label_for'] ]: 0; ?>;
        const getJSON = async function (url, errorMsg = 'Something went wrong') {
            return fetch(url).then(response => {
                if (!response.ok) throw new Error(`${errorMsg} ${response.status}`);
                return response.json();
            });
        };
        const fetchBrands = async () => {
            const brands = await getJSON(  '<?php echo $ajax_url; ?>?action=mbek_get_brands')
                .then((brands) => {
                    console.log('brands: ', brands);
                    const el = jQuery("#brand_filter");
                    // el.empty(); // remove old options
                    jQuery.each(brands.data, function(key,value) {
                        el.append(jQuery("<option></option>")
                            .attr("value", value.id).text(value.display_name));
                    });
                    if (brand_filter) {
                        jQuery('#brand_filter').val(brand_filter);
                    }
                });
        };
        fetchBrands();
    </script>
    <?php
}
/**
 * Top level menu callback function
 */
function wcc_options_page_html() {
	// check user capabilities
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	wp_enqueue_style( 'mbek_bootstrap_style', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css', array(), WCC_VERSION, 'all' );
	wp_enqueue_script( 'mbek_bootstrap_js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js', array(), WCC_VERSION, true );

	// add error/update messages.

	// check if the user have submitted the settings.
	// WordPress will add the "settings-updated" $_GET parameter to the url.
	if ( isset( $_GET['settings-updated'] ) ) {
		// add settings saved message with the class of "updated".
		add_settings_error( 'wcc_messages', 'wcc_message', __( 'Settings Saved', 'wcc' ), 'updated' );
	}

	// show error/update messages.
	settings_errors( 'wcc_messages' );
	?>
    <div class="wrap container">
        <h1>Careers Settings</h1>
        <div class="col-10">
            <form action="options.php" method="post">
		        <?php
		        // output security fields for the registered setting "wcc".
		        settings_fields( 'wcc' );
		        // output setting sections and their fields.
		        // (sections are registered for "wcc", each field is registered to a specific section).
		        do_settings_sections( 'wcc' );
		        // output save settings button.
		        submit_button( 'Save Settings' );
		        ?>
            </form>
        </div>

    </div>
	<?php
}
