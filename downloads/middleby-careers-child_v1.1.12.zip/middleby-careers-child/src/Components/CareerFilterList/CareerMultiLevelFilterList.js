import React, { useState, useEffect } from 'react';
import CareerFilterItem from "../CareerFilterItem/CareerFilterItem";
import {getJSON, renderError} from "../../Helpers";
import OpenCloseIcon from "../UI/Icons/OpenCloseIcon";

const CareerMultiLevelFilterList = props => {
    const [terms, setTerms] = useState([]);
    const [show, setShow] = useState(false);

    useEffect(() => {
        const fetchTerms = async () => {
            const terms = await getJSON(wcc_ajax_url + '?action=get_terms&parent=' + props.term.term_id)
                .then((terms) => {
                    if (!terms.success) {
                        renderError(terms.data[0].message);
                        // throw new Error(`Error: Something went wrong!`)
                    } else {
                        const newTerms = terms.data.map((term) => {
                            term.checked = false;
                            return term;
                        });
                        // console.log(newTerms);
                        setTerms(newTerms);
                    }
                })
                .catch((err) => renderError(err));
        };
        if (props.term) {
            fetchTerms();
        }

    }, []);

    const onChangeHandler = (term_id, checked) => {
        // console.log('term_id: ', term_id, checked);
        props.onItemChangeActive(term_id, checked);
        props.term.checked = checked;
    };

    const onMainFilterClickHandler = (event) => {
        setShow(!show);
    };

    return (
        <div className='filter_div'>
            <h3 onClick={onMainFilterClickHandler}>{props.term.name}
                <OpenCloseIcon show={show} />
            </h3>
            <div className={`filter_choices ${show ? 'show' : ''}`}>
                {terms.map((term) => {
                    // console.log('CareerMultiLevelFilterList', term);
                    if (!props.activeDepartments.find((dTerm) => {
                        return dTerm.term_id === term.term_id;
                    })) {
                        term.checked = false;
                        term.disabled = true;
                    } else {
                        if (props.term.checked === undefined) {
                            term.checked = false;
                            term.disabled = false;
                        } else if (props.term.checked === false) {
                            term.checked = false;
                            term.disabled = true;
                        } else if (props.term.checked === true) {
                            term.checked = true;
                            term.disabled = false;
                        }
                        // term.checked = false;

                    }
                    return <CareerFilterItem key={term.term_id} term={term} onItemChangeActive={onChangeHandler} />
                })}
            </div>
        </div>
    );
};

export default CareerMultiLevelFilterList;