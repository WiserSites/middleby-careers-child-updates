<?php
add_shortcode('middleby-careers-app', function( $atts ){
    $options           = get_option( 'wcc_options' );
    $brand_filter      = $options['wcc_brand_filter'] ?? '';
    $share_title       = $options['wcc_share_title'] ?? '';
    $share_button      = $options['wcc_share_button'] ?? '';
    $wcc_share_content = $options['wcc_share_content'] ?? '';
    // Enqueue scripts.
	wp_enqueue_script('wcc-front-js', WCC_PLUGIN_URL . 'dist/bundle.js', array(), WCC_VERSION,true );
    wp_enqueue_style('wcc-fontawesome-style', WCC_PLUGIN_URL . 'resources/Fontawesome/css/all.min.css', WCC_VERSION, 'all' );
	$atts = shortcode_atts(
		array(
			'site_id' => null,
			'brand'   => null,
		),
		$atts, 'wiser-careers'
	);
	ob_start();
    $options = get_option('wcc_options');
    $paylocity_key = ( ! empty( $options['wcc_paylocity_key'] ) ) ? $options['wcc_paylocity_key'] : '';
	?>
	<div id="app_container"></div>
    <script>
        const wcc_ajax_url = '<?php echo admin_url( 'admin-ajax.php' ); ?>';
        const wcc_top_offset = 150;
        const wcc_paylocity = '<?php echo $paylocity_key; ?>';
        const wcc_share_title = '<?php echo esc_js( $share_title ); ?>';
        const wcc_share_content = '<?php echo esc_js( $wcc_share_content ); ?>';
        const wcc_share_button = '<?php echo esc_js( $share_button ); ?>';
        <?php if ($brand_filter) {
            echo 'const wcc_brand_filter = \'' . $brand_filter . '\'';
        }?>
    </script>
	<?php
	$html = ob_get_contents();
	ob_end_clean();
	return $html;
});
