import React, {useState} from 'react';
import FilterPositionSelectOption from "./FilterPositionSelectOption";

const FilterPositionSelectItem = (props) => {
    const changeSelected = (newSelect) => {
        props.onItemChangeActive(newSelect, true);
    };

    if (!props.show) {
        return null;
    }

    let currentSelection = '';
    if (props.currentSelect) {
        currentSelection = props.currentSelect[0];
    }

    return (
        <div className="col-sml-12 col-md-3">
            <div className="mb-3">
                <label>{props.title}</label>
                <select
                    onChange={(event) => changeSelected(event.target.value)}
                    value={currentSelection}
                    className="form-select"
                    aria-label="Default select">
                    <option value="">- Select {props.title} -</option>
                    {props.options.map((option) => <FilterPositionSelectOption key={option.id} option={option} filtered={props.filtereditems} />)}
                </select>
            </div>
        </div>
    );
};

export default FilterPositionSelectItem;
