import React, {useEffect, useState} from 'react';

// import ClearFilter from "../UI/Button/ClearFilter";
// import CareerMultiLevelFilterList from "../CareerFilterList/CareerMultiLevelFilterList";
import CareerSingleLevelFiltertList from "../CareerFilterList/CareerSingleLevelFiltertList";
import BrandFilterList from "../CareerFilterList/BrandFilterList";
import './CareerFilters.css';
import {careerScrollToTop, getJSON, renderError} from "../../Helpers";
import FilterBrandSelectItem from "../CareerFilterItem/FilterBrandSelectItem";
import FilterCategorySelectItem from "../CareerFilterItem/FilterCategorySelectItem";
import FilterSearch from "../CareerFilterItem/FilterSearch";
import FilterPositionSelectItem from "../CareerFilterItem/FilterPositionSelectItem";

const CareerFilters = (props) => {
    const [brandSelected, setBrandSelected] = useState('');
    const [departmentSelected, setDepartmentSelected] = useState('');
    const [locationSelected, setLocationSelected] = useState('');
    const [showBrands, setShowBrands] = useState(false);
    const [showDepartments, setShowDepartments] = useState(false);
    const [showLocations, setShowLocations] = useState(false);

    useEffect(() => {
        const getOptions = async () => {
            const options = await getJSON( wcc_ajax_url + '?action=mbek_get_options' )
                .then((options) => {
                    if (!options.success){
                        if (!options) {
                            renderError('ERROR: No options found!');
                        } else {
                            renderError(options.data[0].message);
                        }
                    } else {
                        // console.log('options: ', options);
                        props.fetchAllOption(options.data.fetch_all);
                        // options.data.fetch_all === true &&
                        if (options.data.show_brands) {
                            setShowBrands(true);
                        }
                        if (options.data.show_departments) {
                            setShowDepartments(true);
                        }
                        if (options.data.show_locations) {
                            setShowLocations(true);
                        }
                        if (options.data.brand_filter) {
                            // Find correct brand.
                            const brand_filtered = props.brands.find((brand) => brand.id == options.data.brand_filter);
                            // console.log('brand_filtered: ', brand_filtered);
                            onBrandChanged(brand_filtered, true);
                        }
                    }
                })
                .catch((err) => renderError(err))
                .finally();
        };
        getOptions();
    }, []);

    const onItemChanged = (term_id, isChecked) => {
        props.onChangeFilter(term_id, isChecked);
    };
    const onDepartmentChanged = (term_id, isChecked) => {
        props.onChangeDepartment(term_id, isChecked, 'department');
    };
    const onPositionChanged = (job_id, isChecked) => {
        // console.log('selected', job_id);
        props.onChangePosition(job_id, isChecked, 'position');
    };
    const onLocationChanged = (term_id, isChecked) => {
        props.onChangeDepartment(term_id, isChecked, 'location');
    };
    const onBrandChanged = (brand, isChecked) => {
      // console.log('onBrandChanged', brand, isChecked);
        props.onChangeBrand(brand, isChecked);
    };

    const onSearchChanged = (newSearch) => {
        props.onChangeSearch(newSearch);
    };

    const onClearAllHandler = (event) => {
        props.resetFilters();
    };

  // console.log('brand selected: ', props.brandSelected);

    return (
        <div className='career-filters-col'>
            <div className='filters_div row'>

                <FilterBrandSelectItem
                    title='Brand'
                    options={props.brands}
                    onBrandChangeActive={onBrandChanged}
                    show={showBrands}
                    currentSelect={props.brandSelected}
                />

                <FilterCategorySelectItem
                    title='Department'
                    options={props.departments}
                    filtereditems={props.filteredDepartments}
                    onItemChangeActive={onDepartmentChanged}
                    currentSelect={props.departmentSelected}
                    show={showDepartments}
                />

                <FilterCategorySelectItem
                    title='Location'
                    options={props.locations}
                    filtereditems={props.filteredLocations}
                    onItemChangeActive={onLocationChanged}
                    currentSelect={props.locationSelected}
                    show={showLocations}
                />

              <FilterPositionSelectItem
                title='Position'
                options={props.jobs}
                filtereditems={props.filteredJobs}
                show='1'
                currentSelect={props.positionSelected}
                onItemChangeActive={onPositionChanged}
              />
            </div>
        </div>

    );
};

export default CareerFilters;
