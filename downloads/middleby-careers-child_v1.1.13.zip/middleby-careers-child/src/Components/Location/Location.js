import React from 'react';

import './Location.css';

const Location = (props) => {
    return (
        <div className="career_location">{props.location}&nbsp;</div>
    );
};

export default Location;

