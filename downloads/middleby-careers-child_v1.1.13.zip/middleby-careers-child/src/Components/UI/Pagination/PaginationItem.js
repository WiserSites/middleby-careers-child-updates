import React from 'react';
import app from "../../../App";

const PaginationItem = props => {
    const itemClickHandler = (event) => {
        event.preventDefault();
        props.onItemClickHandler(props.pageItem);
    };

    if (props.currentPage === props.pageItem) {
        return (
            <span aria-current='page' className='page-numbers current'>{props.pageItem}</span>
        );
    }

    return (
        <a onClick={itemClickHandler} href='' className='page-numbers'>{props.pageItem}</a>
    );
};

export default PaginationItem;