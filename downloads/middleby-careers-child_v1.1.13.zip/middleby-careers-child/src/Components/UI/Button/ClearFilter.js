import React from 'react';

import './ClearFilter.css';

const ClearFilter = props => {

    const onClickHandler = (event) => {
        // console.log('clicked!!!');
        props.onClearAll();
    };

    return <button className='button career-clear-btn text-white bg-secondary' onClick={onClickHandler}>Clear Filters</button>;
};

export default ClearFilter;