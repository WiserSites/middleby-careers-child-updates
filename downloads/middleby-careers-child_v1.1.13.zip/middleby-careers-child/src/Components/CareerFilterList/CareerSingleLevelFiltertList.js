import React, {useEffect, useState} from 'react';
import CareerFilterItem from "../CareerFilterItem/CareerFilterItem";
import OpenCloseIcon from "../UI/Icons/OpenCloseIcon";

const CareerSingleLevelFiltertList = props => {
    const [show, setShow] = useState(false);

    const onChangeHandler = (term_id, checked) => {
        props.onItemChangeActive(term_id, checked);
    };

    const onMainFilterClickHandler = (event) => {
        setShow(!show);
    };

    if (props.departments.length === 0) {
        // return null;
    }

    return (
        <div className='filter_div'>
            <h3 onClick={onMainFilterClickHandler}>{props.title}
                <OpenCloseIcon show={show} />
            </h3>
            <div className={`filter_choices ${show ? 'show' : ''}`}>
                {props.departments.map((term) => {
                    if (!props.filters.find((dTerm) => {
                        return dTerm.term_id === term.term_id;
                    })) {
                        term.disabled = true;
                    } else {
                        term.disabled = false;
                    }
                    return <CareerFilterItem key={term.term_id} term={term} onItemChangeActive={onChangeHandler} />
                })}
            </div>
        </div>
    );
};

export default CareerSingleLevelFiltertList;