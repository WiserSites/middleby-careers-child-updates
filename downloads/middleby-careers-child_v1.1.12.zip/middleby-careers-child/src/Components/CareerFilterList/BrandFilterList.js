import React, {useEffect, useState} from 'react';

import BrandFilterItem from "../CareerFilterItem/BrandFilterItem";
import OpenCloseIcon from "../UI/Icons/OpenCloseIcon";

const BrandFilterList = props => {
    const [show, setShow] = useState(false);

    const onChangeHandler = (brand, checked) => {
        props.onBrandChangeActive(brand, checked);
    };

    const onMainFilterClickHandler = (event) => {
        setShow(!show);
    };

    if (props.brands.length === 0) {
        return null;
    }
    // console.log('prop.brands', props.brands);

    return (
        <div className='filter_div'>
            <h3 onClick={onMainFilterClickHandler}>{props.title}
                <OpenCloseIcon show={show} />
            </h3>
            <div className={`filter_choices ${show ? 'show' : ''}`}>
                {props.brands.map((brand) => {
                    // console.log('brand: ',brand);
                    if (!props.filters.find((aBrand) => {
                        // console.log('aBrand: ', aBrand);
                        return aBrand.term_id === brand.id;
                    })) {
                        brand.disabled = true;
                    } else {
                        brand.disabled = false;
                    }
                    return <BrandFilterItem key={brand.id} brand={brand} onItemChangeActive={onChangeHandler} />
                })}
            </div>
        </div>
    );
};

export default BrandFilterList;
