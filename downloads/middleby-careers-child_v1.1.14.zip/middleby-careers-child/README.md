# Middleby Careers Child Plugin

Middleby Careers Child Plugin is a WordPress plugin designed to display career opportunities. It integrates with the Paylocity API and provides a customizable frontend experience.

## Installation

1. Upload the plugin files to the `/wp-content/plugins/middleby-careers-child` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.

## Setup & Configuration

Once activated, navigate to the **Careers Settings** page in the WordPress admin to configure the plugin.

### API Settings
- **Fetch All Middleby**: Check this to fetch all jobs from the Middleby API.
- **Show Brands/Departments/Locations**: Toggle visibility of these filters on the frontend.
- **Application Username/Password**: Enter your Middleby API credentials.
- **Paylocity KEY**: Enter your Paylocity API key.
- **Brand Filter**: Select a specific brand to filter results by default.
- **Share Info**: Customize the title, content, and button text for sharing job listings.

## Usage

To display the careers application on any page or post, use the following shortcode:

`[middleby-careers-app]`

Optional attributes (if supported by specific implementations):
- `site_id`: Filter by site ID.
- `brand`: Filter by brand.

## Setup for Developers

### Prerequisites
- Node.js version 20.17.0
- Recommended: nvm (Node Version Manager)

### Development Workflow

1. **Install dependencies**:
   ```bash
   nvm use 20.17.0
   export NODE_OPTIONS=--openssl-legacy-provider
   npm install
   ```

2. **Start development server (watch mode)**:
   ```bash
   npm run watch
   ```

3. **Build for Production**:
   ```bash
   npm run build
   ```

## License
Simple Schema - [wisersites.com](https://wisersites.com)