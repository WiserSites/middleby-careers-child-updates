# Middleby Careers Plugin

## Setup for Devs
First install all npm modules
Use Version 20.17 Node
Best to use nvm
nvm use 20.17.0
export NODE_OPTIONS=--openssl-legacy-provider

`npm install`

Start up for dev

`npm run watch`

Build for Production environment

`npm run build`