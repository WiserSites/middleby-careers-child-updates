import React from 'react';

const Share = (props) => {

    if (wcc_paylocity.trim() == '') {
        return null;
    }

    const shareUrl = `https://recruiting.paylocity.com/Recruiting/PublicLeads/New/${wcc_paylocity}`;
    const shareTitle = wcc_share_title ?  wcc_share_title: 'Not Finding What You\'re Looking For?';
    const shareContent = wcc_share_content ? wcc_share_content : 'Share your information and we will contact you if new opportunities fitting your qualifications become available';
    const shareButtonTxt = wcc_share_button ? wcc_share_button : 'Share Your Information';

    return (
        <div className="row">
            <div className="col-sm-12 text-center">
                <p><strong>{shareTitle}</strong></p>
                <p>{shareContent}</p>
                <a href={shareUrl} target='_blank' className='btn btn-outline-primary'>{shareButtonTxt}</a>
            </div>
        </div>
    );

};

export default Share;