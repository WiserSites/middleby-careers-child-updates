<div class="wrap">
        <h1>Careers Settings</h1>
        <div>
	        <code>[middleby-careers-app]</code>
        </div>
    </div>