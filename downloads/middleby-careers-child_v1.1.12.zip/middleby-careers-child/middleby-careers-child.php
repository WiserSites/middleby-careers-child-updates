<?php
/*
Plugin Name:    Middleby Careers Child Plugin
Plugin URI:     wisersites.com
Description:    Middleby Careers Plugin is the best Careers plugin around.
Author:         Simple Schema
Version:        1.1.12
Author URI:     https://wisersites.com
Promo Paragraf: Middleby Careers Child Plugin
*/

define( 'WCC_VERSION', '1.1.12' );
define( 'WCC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WCC_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCC_PROTECTION_H', plugin_basename( __FILE__ ) );
define( 'WCC_NAME', 'middleby-careers-child' );
define( 'WCC_DOMAIN', 'middleby-careers' );
define( 'WCC_PAGE_LINK', 'middleby-careers' );

function iwcc_print( $array ) {
	echo '<pre>';
	print_r( $array );
	echo '</pre>';
}

register_activation_hook( __FILE__, array( 'WCC', 'plugin_activation' ) );
register_deactivation_hook( __FILE__, array( 'WCC', 'plugin_deactivation' ) );

require_once WCC_PLUGIN_DIR . 'lib/class.wcc.php';
require_once WCC_PLUGIN_DIR . 'lib/shortcodes.php';

add_action( 'init', array( 'WCC', 'init' ) );

if ( is_admin() ) {
	require_once( WCC_PLUGIN_DIR . 'lib/class.wcc-admin.php' );
	add_action( 'init', array( 'WCC_Admin', 'init' ) );
}

require_once WCC_PLUGIN_DIR . 'lib/plugin-update-checker/plugin-update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
	'https://bitbucket.org/wisersites/wiser-careers-child-updates/raw/master/info.json',
	__FILE__,
	'middleby-careers-child-updates'
);
