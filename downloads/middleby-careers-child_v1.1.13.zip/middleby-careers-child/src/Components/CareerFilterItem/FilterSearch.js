import React, {Fragment, useState} from 'react';

const FilterSearch = (props) => {
    // const [q, setQ] = useState('');

    const changeAction = (newSearch) => {
        // console.log(newSearch);
        // setQ(newSearch.target.value);
        props.onSearchChangeActive(newSearch.target.value);
    };

    return (
        <div className="col-sml-12 col-md-3">
            <div className="mb-3">
                <label>{props.title}</label>
                <input
                    type="search"
                    id="app_search"
                    name="app_search"
                    className="form-control"
                    placeholder="Search For..."
                    value={props.q}
                    onChange={changeAction}
                />
            </div>
        </div>
    );
};

export default FilterSearch;