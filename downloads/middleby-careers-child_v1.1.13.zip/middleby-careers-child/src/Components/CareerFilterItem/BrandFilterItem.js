import React from 'react';

const BrandFilterItem = (props) => {

    const onChangeHandler = (event) => {
        props.onItemChangeActive(props.brand, event.target.checked);
        props.brand.checked = !props.brand.checked;
    };

    const checked = (props.brand.checked) ? true : false;

    return (
        <label key={props.brand.id}>
            <input
                type='checkbox'
                onChange={onChangeHandler}
                checked={checked}
                disabled={props.brand.disabled} /> {props.brand.display_name}
        </label>
    );
};

export default BrandFilterItem;