import React, {useState} from "react";
import "@fontsource/fira-sans";

import CareerList from './Components/CareerList/CareerList';
import CareerDetail from "./Components/CareerDetail/CareerDetail";

import "./App.css";
import './assets/css/bootstrap.min.css';
import ClearFilter from "./Components/UI/Button/ClearFilter";

const DUMMY_JOB = {
    id: 0,
    title: '',
    company_name: '',
    description: '',
    requirements: '',
    location: '',
    terms: []
};

const App = (props) => {
    const [show, setShow] = useState(false);
    const [job, setJob] = useState(DUMMY_JOB);

    const onShowHandler = (job) => {
        setShow(job);
        setJob(job);
    };

    const onCloseHandler = (event) => {
        setShow(false);
        setJob(DUMMY_JOB);
    };
    return (
        <div id='career-app' className='container-fluid'>
            <CareerDetail show={show} job={job} onCloseCommand={onCloseHandler}/>
            <CareerList onShow={onShowHandler}/>
        </div>
    );
};

export default App;