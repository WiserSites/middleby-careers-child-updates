import React from 'react';

const FilterCategorySelectOption = (props) => {
    const disabledStatus = ! props.filtered.find((term) => term.term_id === props.option.term_id);
    return (
        <option key={props.option.term_id} value={props.option.term_id} disabled={disabledStatus} >
            {props.option.name}
        </option>
    );
};

export default FilterCategorySelectOption;
