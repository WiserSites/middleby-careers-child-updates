import React from 'react';

const CareerFilterItem = (props) => {
    // const [isChecked, setIsChecked] = useState(false);

    const onChangeHandler = (event) => {
        props.onItemChangeActive(props.term.term_id, event.target.checked);
        props.term.checked = !props.term.checked;
    };

    // console.log('term', props.term);
    const checked = (props.term.checked) ? true : false;

    return (
        <label key={props.term.name}>
            <input type='checkbox' onChange={onChangeHandler} checked={checked} disabled={props.term.disabled} /> {props.term.name}
        </label>
    );
};

export default CareerFilterItem;