import React from 'react';

import DOMPurify from 'dompurify';

const CareerDetailDescription = (props) => {
    if (props.description.trim() === '') {
        return null;
    }
    const sanitizeData = () => ({
        __html: DOMPurify.sanitize(props.description, {USE_PROFILES: {html: true}})
    });

    return (
        <div className='col-12'>
            <strong>{props.title}</strong>
            <div dangerouslySetInnerHTML={sanitizeData()}></div>
        </div>
    );
};

export default CareerDetailDescription;