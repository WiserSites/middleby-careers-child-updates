import React, { useState } from 'react';

import ApplyNow from "../UI/Button/ApplyNow";
import CareerDetailDescription from "./CareerDetailDescription";

import './CareerDetail.css';

const CareerDetail = (props) => {
    if (!props.show) {
        return null;
    }

    const onClickHandler = (event) => {
        props.onCloseCommand(true);
    };

    const panelOffset = (wcc_top_offset) ? wcc_top_offset : 0;
    const mySideBarStyle = {
        top: panelOffset
    }
    const showBrandUrl = () => {
        if ( ! props.job.brand.brand_url ) {
            return props.job.brand.name;
        }
        return  <a target='_blank' href={props.job.brand.brand_url}>{props.job.brand.name}</a>
    };
    return (
        <div className="career_modal" onClick={onClickHandler}>
            <div className={`career_sidebar_panel ${props.show ? 'show' : ''}`} style={mySideBarStyle}>
                <div className='row'>
                    <div className={`col-12 career_sidebar_panel__title`}>
                        <div className='row'>
                            <div className='col-xs-12 col-sm-8 col-lg-8'>
                                <h4>{props.job.title}</h4>
                                <div>
                                    {props.job.company_name}
                                </div>
                                <div>
                                    {showBrandUrl()}
                                </div>
                            </div>
                            <div className='col-xs-12 col-sm-4 col-lg-4'>
                                <ApplyNow job={props.job} />
                                <div className="title__location">
                                    {props.job.location}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="career_sidebar_panel__content">
                        <div className='row'>
                            <CareerDetailDescription title='Description' description={props.job.description} />
                            <CareerDetailDescription title='Requirements' description={props.job.requirements} />
                            <CareerDetailDescription title='Salary Description' description={props.job.salary_description} />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CareerDetail;