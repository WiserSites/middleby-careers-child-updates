import React from 'react';

import './ApplyNow.css';

const ApplyNow = (props) => {
    if ( ! props.job.apply_url ) {
        return null;
    }

    return (
        <a className='applynow-btn button bg-secondary text-white' href={props.job.apply_url} target='_blank'>Apply Now</a>
    );
};

export default ApplyNow;