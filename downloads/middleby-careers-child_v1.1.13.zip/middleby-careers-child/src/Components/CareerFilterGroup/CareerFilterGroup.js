import React from 'react';
import CareerFilterItem from "../CareerFilterItem/CareerFilterItem";

const CareerFilterGroup = (props) => {
    const onItemChangeActive = (term_id, isChecked) => {
        props.onItemChanged(term_id, isChecked);
    };

    console.log(props.items);

    return (
        <div className='filter_div'>
            {props.items.map((term) => {
                return <CareerFilterItem key={term.term_id} term={term} onItemChangeActive={onItemChangeActive} />
            })}
        </div>
    );
};

export default CareerFilterGroup;